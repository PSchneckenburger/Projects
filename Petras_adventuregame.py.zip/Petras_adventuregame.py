import time
import random
import string

weapon = random.choice(["dagger", "knife", "sword", "scissor"])
# other things to do:  print inventory,
# call change_location only in the start function: while True


def print_message(message):
    print(message)
    time.sleep(2)


# checks the responses given
def check_response(prompt, options):
    nasty_words = ["fuck", "fucking" "piss", "shit", "damn", "hell"]
    while True:
        response = input(prompt).lower().strip(string.punctuation)
        for word in nasty_words:
            if word in response:
                print_message("\033[31m You should not use such a "
                              "nasty word! \033[0;37m")
        for word in options:
            while word in response:
                return response
        print_message("Please try again")


# gives out the possible moves
def change_location(location, inventory, t, c):
    options = ["up", "down", "left", "right"]
    response = check_response("Where do you want to turn to? (up, down, "
                              "left, right)\n", options)
    if "up" in response:
        look_up(location, inventory, t, c)
    elif "down" in response:
        look_down(location, inventory, t, c)
    elif "left" in response:
        if location == "castle":
            tree(location, inventory, t, c)
        elif location == "tree":
            cave(location, inventory, t, c)
        elif location == "cave":
            castle(location, inventory, t, c)
    elif "right" in response:
        if location == "castle":
            cave(location, inventory, t, c)
        elif location == "tree":
            castle(location, inventory, t, c)
        elif location == "cave":
            tree(location, inventory, t, c)


# decides what happens, when hero looks up.
def look_up(location, inventory, t, c):
    if location == "tree" or location == "castle":
        if "ring" in inventory:
            print_message("You look up, but nothing happens.")
            print_message("What did you expect? Now eagles are extinct!")
            change_location(location, inventory, t, c)
        else:
            eagle_attack(location, inventory, t, c)
    elif location == "cave":
        if weapon in inventory:
            print_message("A giant stone falls on you and squeezes you!")
            if weapon == "scissor":
                print_message("Maybe paper would have been better?")
                play_again()
            else:
                print_message("Sorry, but you should never feel too sure "
                              "with a weapon in your hand! ")
                play_again()
        else:
            eagle_attack(location, inventory, t, c)


# decides what happens when hero looks down.
def look_down(location, inventory, t, c):
    if location == "castle":
        if "matches" not in inventory:
            print_message("You look down to your feet and find a box "
                          "with matches.")
            inventory.append("matches")
            change_location(location, inventory, t, c)
    elif location == "cave":
        if "glove" not in inventory:
            print_message("You look down to your feet and find "
                          "a glove.")
            inventory.append("glove")
            change_location(location, inventory, t, c)
    print_message("You look down to your feet and find nothing.")
    change_location(location, inventory, t, c)


# decides what happens on eagle attack, depending on collected item
def eagle_attack(location, inventory, t, c):
    print_message("An Eagle 🦅  comes heading down to you and attacks you!")
    if weapon in inventory:
        print_message(f"You stab  the Eagle with your {weapon} and kill him.")
        if "key" in inventory:
            print_message("The bird had a beautiful ring 💍  in its claws!")
            inventory.append("ring")
            change_location(location, inventory, t, c)
        else:
            print_message("The Eagle had a key 🗝️  in its beak!")
            inventory.append("key")
            change_location(location, inventory, t, c)
    else:
        print_message("You can't defend yourself and you die!\n")
        print_message("You should never look up when you have no weapon!!\n")
        play_again()


# special action at the tree
def tree(location, inventory, t, c):
    location = "tree"
    t += 1    # counts the visits
    if t == 2:  # different action when hero comes the second time
        print_message("You go back to the tree. This time  you examin "
                      "the trunk carefully.")
        print_message(f"There is a hole and you find a {weapon}.")
        print_message("You are happy because now you can look up safely!")
        inventory.append(weapon)
        change_location(location, inventory, t, c)
    else:
        print_message("You go to the tree")
        change_location(location, inventory, t, c)


# special action at the cave
def cave(location, inventory, t, c):
    location = "cave"
    c += 1    # counts the visits
    if c == 2:    # different action when the hero comes the second time
        print_message("You decide to enter the cave.")
        if "matches" in inventory:
            print_message("You lighten a match and go inside.")
            print_message("When you made a few steps, you hear a rumble and "
                          "the ground starts shaking!")
            print_message("You head to the entrance, but it is locked by a "
                          "boulder avalanche")
            print_message("There is no way out, the game is over")
            play_again()
        else:
            print_message("It is dark in the cave, but through the opening "
                          "falls a faint light.")
            print_message("When you made a few steps, you hear a rumble "
                          "and the ground starts shaking")
            print_message("Suddenly it is pitch black around you. "
                          "The entrance is locked!")
            print_message("Sadly, you'll never find a way out, the game is "
                          "over!")
            play_again()
    else:
        print_message("You go to the cave")
        change_location("cave", inventory, t, c)


# what happens in the castle
def castle(location, inventory, t, c):
    location = "castle"
    print_message("You go to the castle")
    if "key" in inventory:
        if "ring" in inventory:
            print_message("You use the key and open the door")
            print_message("In the hallway you see a table.")
            print_message("On the table sits a beautiful colored frog 🐸")
            print_message("What do you want to do with the frog?")
            options = ["kiss", "throw"]
            response = check_response("Kiss the frog or throw it at the wall?"
                                      "(kiss, throw)\n", options)
            if "kiss" in response:
                print_message("You kiss the frog and die.")
                print_message("You should have read Grimms Tales carefully.")
                play_again()
            elif "throw" in response:
                if "glove" in inventory:
                    print_message("You put on the glove, take the frog and "
                                  "throw it at the wall")
                    outro()  # coming to the end
                else:
                    print_message("You take the frog and throw it at the wall")
                    print_message("The frog fells down and is dead.")
                    print_message("Alas, you also die, because it is "
                                  "a poisonous treefrog.")
                    play_again()
        else:
            print_message("You have the key, but you also need another item.")
            print_message("Go around again and examin everything carefully!")
            change_location(location, inventory, t, c)
    else:
        print_message("The door is locked, you need a key")
        change_location(location, inventory, t, c)


def play_again():
    options = ["yes", "no"]
    response = check_response("Do you want to play again?(yes, no)\n", options)
    if "no" in response:
        print_message("Thanks for playing and good bye!\n\n")
        exit()
    else:
        play_adventure()


def intro():
    print_message("You are standing on a small path overgrown with weed.")
    print_message("You feel dizzy and you can't remember how you got here.")
    print_message("A few steps beyond is a castle 🏰.")
    print_message("On your left is a huge oak tree 🌳, on your right "
                  "side opens the mouth of a dark cave 🕳️.")
    print_message("You go to the castle, but the door is locked.")
    print_message("You decide to search for the key.")
    print_message("As an experienced adventuregame player you know that you "
                  "have to run around and collect everything you find.")
    print_message("But be careful, death is lurking everywhere!")


def outro():
    print_message("The frog fell down from the wall, but nothing happend.")
    print_message("You look after him and find him dead!\n")
    print_message("Have you thought to be in a fairytale?")
    print_message("This is just a silly game someone is playing with you.")
    print_message("Go, leave the castle, sell the golden ring.")
    print_message("Use the money to enroll in a nanodegree coding program"
                  "so you can write silly adventuregames yourself!\n")
    print_message("And you shall live happily forever!")
    exit()


def start_game():

    inventory = []  # stores the found items
    t = 0           # counts  visits at tree
    c = 0           # counts  visits at cave
    location = "castle"
    change_location(location, inventory, t, c)
    # location, inventory, t, c have to be passed to the functions


def play_adventure():
    intro()
    start_game()


play_adventure()
