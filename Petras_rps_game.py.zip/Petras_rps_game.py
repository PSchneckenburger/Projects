#!/usr/bin/env python3
import random

"""This program plays a game of Rock, Paper, Scissors between two Players,
and reports both Player's scores each round."""
"""The Player class is the parent class for all of the Players
in this game"""


moves = ['rock', 'paper', 'scissors']
moves_rpsls = ['rock', 'paper', 'scissors', 'lizard', 'spock']


class Player:

    my_move = None
    their_move = None
    totalscore = 0

    def move(self):
        return 'rock'

    def learn(self, my_move, their_move):
        pass

    def addscore(self, score):
        self.totalscore += score


class RandomPlayer(Player):

    def move(self):
        return random.choice(moves)

    def addscore(self, score):
        self.totalscore += score


class RpslsRandomPlayer(Player):

    def move(self):
        return random.choice(moves_rpsls)

    def addscore(self, score):
        self.totalscore += score


class CyclePlayer(Player):

    def move(self):
        if self.my_move is None:
            return "rock"
        else:
            return(moves[(moves.index(self.my_move)+1) % 3])

    def learn(self, my_move, their_move):
        self.my_move = my_move
        self.their_move = their_move

    def addscore(self, score):
        self.totalscore += score


class ReflectPlayer(Player):

    def move(self):
        if self.their_move is None:
            return random.choice(moves)
        else:
            return self.their_move

    def learn(self, my_move, their_move):
        self.my_move = my_move
        self.their_move = their_move

    def addscore(self, score):
        self.totalscore += score


class HumanPlayer(Player):

    def move(self):
        while True:
            move = input("(R)ock, (P)aper or (S)cissors?\n").lower()
            if move == "r":
                return "rock"
            elif move == "p":
                return "paper"
            elif move == "s":
                return "scissors"
            else:
                print("Please try again")

    def addscore(self, score):
        self.totalscore += score


class RpslsHumanPlayer(Player):

    def move(self):
        while True:
            move = input("(R)ock, (P)aper, (Sc)issors, (L)izard or "
                         "(Sp)ock?\n").lower()
            if move == "r":
                return "rock"
            elif move == "p":
                return "paper"
            elif move == "sc":
                return "scissors"
            elif move == "l":
                return "lizard"
            elif move == "sp":
                return "spock"
            else:
                print("Please try again")

    def addscore(self, score):
        self.totalscore += score


class StrategicPlayer(Player):

    def learn(self, my_move, their_move):
        self.my_move = my_move
        self.their_move = their_move

    def move(self):
        if self.their_move is None:
            return "paper"
        else:
            if beats(self.my_move, self.their_move):
                return self.their_move
            elif beats(self.their_move, self.my_move):
                return(moves[(moves.index(self.their_move)+1) % 3])
            else:
                return(moves[(moves.index(self.their_move)-1) % 3])
# source for strategy:
# https://gizmodo.com/why-you-suck-at-rock-paper-scissors-1765212724

    def addscore(self, score):
        self.totalscore += score


players = [Player(), RandomPlayer(), CyclePlayer(), ReflectPlayer(),
           StrategicPlayer()]
# player list made global because it is needed in more than one function


def beats(one, two):
    return ((one == 'rock' and two == 'scissors') or
            (one == 'rock' and two == 'lizard')or
            (one == 'scissors' and two == 'paper') or
            (one == 'scissors' and two == 'lizard') or
            (one == 'paper' and two == 'rock') or
            (one == 'paper' and two == 'spock') or
            (one == 'lizard' and two == 'spock') or
            (one == 'lizard' and two == 'paper') or
            (one == 'spock' and two == 'scissors') or
            (one == 'spock' and two == 'rock'))


def check_int(prompt, maximum):
    while True:
        userinput = input(prompt)
        try:
            value = int(userinput)
            if 0 < value <= maximum:
                return value
            else:
                print(f"Please enter a number from 1 - {maximum}")
        except ValueError:
            print("Please enter a number")


class Game:
    def __init__(self, p1, p2):
        self.p1 = p1
        self.p2 = p2

    def play_round(self, p1_name, p2_name):

        move1 = self.p1.move()
        move2 = self.p2.move()

        print(f"{p1_name}: {move1} \t {p2_name}: {move2}")
        if beats(move1, move2):
            self.p1.score += 1
            print(f"{p1_name} : 1 Point  \t {p2_name}: 0 Points")
            print(f"\nThis round goes to {p1_name}")

        elif beats(move2, move1):
            self.p2.score += 1
            print(f"{p1_name}: 0 Points  \t {p2_name}: 1 Point")
            print(f"\nThis round goes to {p2_name}")

        else:
            print(f"{p1_name}: 0 Point  \t  {p2_name}: 0 Point")
            print("\nTie, none of you gets a point")

        print("Score up to now:")
        print(f"{p1_name}: {self.p1.score}\t{p2_name}: {self.p2.score}\n")
        self.p1.learn(move1, move2)
        self.p2.learn(move2, move1)

    def play_game(self, rounds, p1_name, p2_name):

        self.p2.score = 0
        self.p1.score = 0

        print("Game start!\n")
        for round in range(1, rounds+1):
            print(f"Round {round}:")
            self.play_round(p1_name, p2_name)

        print("Game over!\n")
        print("Total scores:")
        print(f"{p1_name}: {self.p1.score} point(s)\t{p2_name}:"
              f"{self.p2.score} point(s)\n")
        if self.p1.score > self.p2.score:
            print(f"{p1_name} is the winner of this game!\n")
        elif self.p2.score > self.p1.score:
            print(f"{p2_name} is the winner of this game!\n")
        else:
            print("Tie, that was a balanced game!\n")
        self.p1.addscore(self.p1.score)  # saves score needed for tournament
        self.p2.addscore(self.p2.score)  # saves score needed for tournament
        total = str(self.p1.score) + ":" + str(self.p2.score)
        return total


def setup():

    names = ["Rocky", "Randy", "Galileo", "Mimy", "Einstein"]

    print("Welcome to rock, paper, scissors\n")
    hp_name = input("Please enter your name:\n")

    print(f"Hi {hp_name}, nice to play with you. You can :\n\n"
          "1. Play a standard Game of 'Rock Paper Scissors'\n\n"
          "2. Try an extended version: Rock Paper Scissors Lizard Spock\n"
          "   Rules: Scissors cuts Paper,\n"
          "\t  Paper covers Rock,\n"
          "\t  Rock crushes Lizard,\n"
          "\t  Lizard poisons Spock,\n"
          "\t  Spock smashes Scissors,\n"
          "\t  Scissors decapitates Lizard\n"
          "\t  Lizard eats Paper,\n"
          "\t  Paper disproves Spock,\n"
          "\t  Spock vaporizes Rock,\n"
          "\t  (and as it always has) Rock crushes Scissors\n\n"
          "3. Watch a tournament of different computer players\n")
    choice = check_int("What do you like to do? (1, 2 or 3)\n", 3)

    if choice == 3:
        print("You will watch a tournament of 5 Players, each game going "
              "over 200 rounds. ")
        input("Press Enter to continue...")
        tournament()
    else:
        if choice == 2:
            p1 = RpslsHumanPlayer()
            p1_name = hp_name
            p2 = RpslsRandomPlayer()
            p2_name = "Sheldon"
        else:
            print("\n Pick your opponent:\n"
                  "  1. Rocky: strong but simple minded\n"
                  "  2. Randy: he's a really lucky guy\n"
                  "  3. Galileo: turning round and round\n"
                  "  4. Mimy: she has an excellent memory\n"
                  "  5. Einstein: do you dare?\n"
                  "  6. Choose me one!\n")
            choice = check_int("Who do you choose? (1-6)\n", 6)

            if choice == 6:
                p2 = random.choice(players)
                p2_name = "U.N.Owen"
            else:
                p2 = players[choice-1]
                p2_name = names[choice-1]

            p1 = HumanPlayer()
            p1_name = hp_name

        rounds = check_int("How many rounds do you want to play?(1-20)\n", 20)
        print(f"You will play {rounds} Rounds against {p2_name}.\n")
        print("For your moves, enter the letters in brackets.\n")

        game = Game(p1, p2)
        game.play_game(rounds, p1_name, p2_name)
# I decided to pass the names here instead of defining them in the player
# classes because of the unknown player and the different player names
# in the tournament


def tournament():

    names = ["Rock  Player", "Random Player", "Cycle Player",
             "Reflect Player", "Strategic Player"]
    results = {}   # stores pairings and results of each game

    for ind1 in range(5):
        for ind2 in range(ind1+1, 5):
            p1_name = names[ind1]
            p2_name = names[ind2]
            pairing = names[ind1] + "  :  " + names[ind2]
            print("Game " + pairing)
            game = Game(players[ind1], players[ind2])
            rounds = 200
            results[pairing] = game.play_game(rounds, p1_name, p2_name)

    input("Press Enter to see a summary of the results:\n")
    print("Results of each game:\n")
    for entry in results.items():
        print(entry)
    print("\n\nFinal results:\n")
    final = []
    for player in players:
        final.append(player.totalscore)
        print(f"{names[players.index(player)]}:   \t{player.totalscore} "
              "Points")
    print(f"\n{names[final.index(max(final))]} is the winner of this "
          "tournament!")


if __name__ == '__main__':
    setup()
